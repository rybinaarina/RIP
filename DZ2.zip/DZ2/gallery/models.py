from django.db import models


class Museum(models.Model):
    Name = models.CharField(max_length=50, unique=True)
    Location = models.CharField(max_length=100)
    History = models.TextField()

    def __str__(self) -> str:
        return f'{self.Name, {self.Location},{self.History}}'


class Art(models.Model):
    Art_pict = models.CharField(max_length=100, default="null")
    name_painter = models.CharField(max_length=100)
    release_year = models.CharField(max_length=50)
    History = models.TextField()
    Img = models.ImageField(upload_to='static/images', default="null")
    Name_Art = models.ForeignKey(Museum, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return f' {self.name_painter},{self.release_year}, {self.History},{self.Art_pict} '
