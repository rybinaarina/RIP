from django.shortcuts import render

from gallery.models import Museum, Art


def gallery(request):
    museum = Museum.objects.all()
    art = Art.objects.all()
    return render(
        request,
        'Details/MainList.html',
        {
            'museum': museum,
            'art': art,
        },
    )
