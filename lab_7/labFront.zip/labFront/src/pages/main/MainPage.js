import {OsCardsComponents} from "../../components/os-cards/OsCardsComponents.js";
import {OsPage} from "../../os/OsPage.js";
import {ajax} from "../../modules/ajax.js";
import {urls} from "../../modules/urls.js";


export class MainPage {
    constructor(parent) {
        this.parent = parent;
    }
    clickCard(e) {
        const cardId = e.target.dataset.id
        const osPage = new OsPage(this.parent, cardId)
        osPage.render()
    }


    get page() {
        return document.getElementById('main-page')
    }

    getHTML() {
        return (
            `
            <div id="main-page" class="d-flex flex-wrap"><div/>
        `
        )
    }

    getData() {
        return ajax.get(urls.oss())
    }

    async render() {
        this.parent.innerHTML = ''
        const html = this.getHTML()
        this.parent.insertAdjacentHTML('beforeend', html)

        const data = await this.getData()
        data.data.forEach((item) => {
            const OSCard = new OsCardsComponents(this.parent)
            OSCard.render(item, this.clickCard.bind(this))
        })
    }


}

