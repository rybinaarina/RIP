export class OsCardsComponents {
    constructor(parent) {
        this.parent = parent;
    }
    addListeners(data, listener) {
        document
            .getElementById(`click-card-${data.pk}`)
            .addEventListener("click", listener)
    }

    getHTML(data) {
        return (
            `
                <div class="card" style="width: 300px;">
                    <div class="card-body">
                        <img src="${data.src}" class="img-fluid" alt="картинка">
                        <h5 class="card-title">${data.os_name}</h5>
                        <p class="card-text">${data.os_descript}</p>
                        <button class="btn btn-primary" id="click-card-${data.pk}" data-id="${data.pk}">Нажми на меня</button>
                    </div>
                </div>
            `
        )
    }
    render(data, listener) {
        const html = this.getHTML(data)
        this.parent.insertAdjacentHTML('beforeend', html)
        this.addListeners(data, listener)
    }


}