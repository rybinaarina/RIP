class Urls {
    constructor() {
        this.url = 'http://localhost:8000/';
    }

    oss() {
        return `${this.url}stocks/`
    }

    os(id) {
        return `${this.url}stocks/${id}/`
    }
}

export const urls = new Urls()